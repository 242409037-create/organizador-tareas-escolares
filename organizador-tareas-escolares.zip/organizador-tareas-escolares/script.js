const STORAGE_KEY = "organizador-tareas-escolares-v1";

const form = document.querySelector("#taskForm");
const titleInput = document.querySelector("#taskTitle");
const subjectInput = document.querySelector("#taskSubject");
const dateInput = document.querySelector("#taskDate");
const taskList = document.querySelector("#taskList");
const taskFilter = document.querySelector("#taskFilter");
const emptyMessage = document.querySelector("#emptyMessage");

let tasks = loadTasks();

function loadTasks() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch (error) {
    console.error("No se pudieron cargar las tareas:", error);
    return [];
  }
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

function formatDate(dateString) {
  if (!dateString) return "Sin fecha de entrega";
  // Añade la hora al mediodía para evitar cambios de día por zona horaria.
  const date = new Date(`${dateString}T12:00:00`);
  return new Intl.DateTimeFormat("es-MX", {
    day: "numeric", month: "short", year: "numeric"
  }).format(date);
}

function updateStats() {
  document.querySelector("#totalCount").textContent = tasks.length;
  document.querySelector("#pendingCount").textContent = tasks.filter(task => !task.completed).length;
  document.querySelector("#completedCount").textContent = tasks.filter(task => task.completed).length;
}

function createTaskCard(task) {
  const card = document.createElement("article");
  card.className = `task-card${task.completed ? " done" : ""}`;

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.className = "task-check";
  checkbox.checked = task.completed;
  checkbox.setAttribute("aria-label", `Marcar ${task.title} como completada`);
  checkbox.addEventListener("change", () => {
    task.completed = checkbox.checked;
    saveTasks();
    renderTasks();
  });

  const content = document.createElement("div");
  content.className = "task-content";

  const title = document.createElement("p");
  title.className = "task-title";
  title.textContent = task.title;

  const meta = document.createElement("div");
  meta.className = "task-meta";

  const subject = document.createElement("span");
  subject.className = "subject-tag";
  subject.textContent = task.subject;

  const date = document.createElement("span");
  date.textContent = `Entrega: ${formatDate(task.date)}`;

  meta.append(subject, date);
  content.append(title, meta);

  const deleteButton = document.createElement("button");
  deleteButton.className = "delete-button";
  deleteButton.type = "button";
  deleteButton.textContent = "Eliminar";
  deleteButton.addEventListener("click", () => {
    tasks = tasks.filter(item => item.id !== task.id);
    saveTasks();
    renderTasks();
  });

  card.append(checkbox, content, deleteButton);
  return card;
}

function renderTasks() {
  taskList.replaceChildren();
  const filter = taskFilter.value;
  const visibleTasks = tasks.filter(task => {
    if (filter === "pending") return !task.completed;
    if (filter === "completed") return task.completed;
    return true;
  });

  visibleTasks.sort((a, b) => {
    if (a.completed !== b.completed) return Number(a.completed) - Number(b.completed);
    if (!a.date) return 1;
    if (!b.date) return -1;
    return a.date.localeCompare(b.date);
  });

  visibleTasks.forEach(task => taskList.append(createTaskCard(task)));
  emptyMessage.hidden = visibleTasks.length > 0;
  emptyMessage.textContent = tasks.length === 0
    ? "Todavía no hay tareas. ¡Agrega la primera!"
    : "No hay tareas que coincidan con este filtro.";
  updateStats();
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const title = titleInput.value.trim();
  const subject = subjectInput.value.trim();
  if (!title || !subject) return;

  tasks.push({
    id: (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`),
    title,
    subject,
    date: dateInput.value,
    completed: false
  });

  saveTasks();
  form.reset();
  renderTasks();
  titleInput.focus();
});

taskFilter.addEventListener("change", renderTasks);
renderTasks();

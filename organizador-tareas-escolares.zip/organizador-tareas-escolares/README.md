# Organizador de Tareas Escolares

Aplicación web sencilla para registrar y organizar tareas escolares. Proyecto de práctica desarrollado con HTML, CSS y JavaScript.

## Funciones

- Agregar tareas con nombre, materia y fecha de entrega.
- Marcar tareas como completadas.
- Eliminar tareas.
- Filtrar entre todas, pendientes y completadas.
- Consultar un resumen de tareas.
- Guardar la información en el navegador con `localStorage`.
- Diseño adaptable a computadoras y dispositivos móviles.

## Tecnologías

- HTML5
- CSS3
- JavaScript
- LocalStorage del navegador

## Cómo ejecutar el proyecto

1. Descarga o clona este repositorio.
2. Abre la carpeta del proyecto.
3. Abre `index.html` en un navegador moderno.

No necesitas instalar dependencias ni configurar un servidor.

## Publicar con GitHub Pages

1. Sube todos los archivos a un repositorio de GitHub.
2. Entra a **Settings → Pages**.
3. En **Build and deployment**, selecciona **Deploy from a branch**.
4. Elige la rama `main` y la carpeta `/ (root)`.
5. Guarda los cambios y espera a que GitHub publique el sitio.

## Nota

Las tareas se guardan únicamente en el navegador y dispositivo donde se agregan. No se sincronizan entre dispositivos.

## Autor

Proyecto educativo para practicar desarrollo web.
